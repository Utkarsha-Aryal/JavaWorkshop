package workshop1;

final class FinalClass{
	final void semiFinal() {
		
	}
}

class finale extends FinalClass{
	final void semiFinal() {
		
	}
	
}

public class Qn6 {
	public static void main(String[] args) {
		
	}

}

